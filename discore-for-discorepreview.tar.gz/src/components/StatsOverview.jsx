import React from 'react';
import { TrendingUp, Users, Server, Award } from 'lucide-react';
import { analyticsData } from '../data/mockData';
import { formatNumber } from '../utils/helpers';

const StatsOverview = () => {
  const stats = [
    {
      icon: Server,
      label: 'Servers Analyzed',
      value: formatNumber(analyticsData.totalServersAnalyzed),
      color: 'text-blue-500',
      bgColor: 'bg-blue-500/10',
      trend: '+12.3%'
    },
    {
      icon: Users,
      label: 'Community Members',
      value: formatNumber(analyticsData.totalCommunityMembers),
      color: 'text-green-500',
      bgColor: 'bg-green-500/10',
      trend: '+8.7%'
    },
    {
      icon: Award,
      label: 'Average Score',
      value: analyticsData.averageScore,
      color: 'text-purple-500',
      bgColor: 'bg-purple-500/10',
      trend: '+2.1%'
    },
    {
      icon: TrendingUp,
      label: 'Top Category',
      value: analyticsData.topPerformingCategory,
      color: 'text-yellow-500',
      bgColor: 'bg-yellow-500/10',
      trend: analyticsData.growthTrend
    }
  ];

  return (
    <section className="py-16 bg-gray-800">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            Platform <span className="text-gradient">Analytics</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Real-time insights from thousands of Discord communities analyzed by our AI
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="glass-effect rounded-2xl p-6 hover:bg-white/10 transition-all duration-300 group"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-xl ${stat.bgColor}`}>
                  <stat.icon className={`w-6 h-6 ${stat.color}`} />
                </div>
                <span className="text-green-400 text-sm font-medium flex items-center">
                  <TrendingUp className="w-4 h-4 mr-1" />
                  {stat.trend}
                </span>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-white group-hover:text-white/90 transition-colors">
                  {stat.value}
                </h3>
                <p className="text-gray-400 text-sm">{stat.label}</p>
              </div>

              {/* Animated progress bar */}
              <div className="mt-4 h-1 bg-gray-700 rounded-full overflow-hidden">
                <div 
                  className={`h-full bg-gradient-to-r from-${stat.color.replace('text-', '')} to-${stat.color.replace('text-', '')}/50 rounded-full transform transition-all duration-1000 delay-${index * 200}`}
                  style={{ width: '100%' }}
                ></div>
              </div>
            </div>
          ))}
        </div>

        {/* Additional info */}
        <div className="mt-12 text-center">
          <div className="inline-flex items-center space-x-4 glass-effect rounded-full px-6 py-3">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-gray-300 text-sm">Live data updates every 5 minutes</span>
            </div>
            <div className="w-1 h-4 bg-gray-600"></div>
            <div className="flex items-center space-x-2">
              <span className="text-gray-300 text-sm">Last updated: just now</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default StatsOverview; 